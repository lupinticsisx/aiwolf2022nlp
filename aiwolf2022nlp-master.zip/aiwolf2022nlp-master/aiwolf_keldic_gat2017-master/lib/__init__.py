from lib import util
from lib import all_pattern
from lib import recognize
from lib import utterance_generator